﻿<?php
$mod='blank';
$title = "叮咚云控系统";
include('head.php');
include('nav.php');
?>
    <div class=" center-block" style="float: none;">
<?php
$user = trim($_GET['user']);
if(!$user || !$row = db(_openvpn_)->where(array(_iuser_=>$user))->find()){ exit("账号不存在!");}
if($_POST['type']=="update"){
echo '<div class="panel panel-default">
<div class="panel-heading"><h3 class="panel-title">修改账号结果</h3></div>
<div class="panel-body">';
$pass = trim($_POST['pass']);
$maxll = trim($_POST['maxll'])*1024*1024;
$state = trim($_POST['state']);
$endtime = strtotime($_POST['enddate']);
	if(db(_openvpn_)->where(array(_iuser_=>$user))->update(array(
			_ipass_=>$pass,
			_maxll_=>$maxll,
			_i_=>$state,
			_endtime_=>$endtime
			))){
		echo '修改成功！';
	}else{
		echo '修改失败！';
	}
echo '<hr/><a href="./user_list.php">>>返回账号列表</a></div></div>';
exit;
}
?>


<script src="js/amcharts.js" type="text/javascript"></script>
<script src="js/serial.js" type="text/javascript"></script>
<script src="js/pie.js" type="text/javascript"></script>
<style>
.main
{
	
	height: 400px;
	
	margin:10px;
	margin-top: 20px;
	overflow: hidden;
}

#line
{
	width: 100%;
	height: 400px;
	
}
#pie
{
	width: 100%;
	height: 400px;
	
}


</style>

<div class="panel panel-default">
        <div class="panel-heading"><h3 class="panel-title">账号:<?=$user?> 近30天流量走势（流量统计以断开时间为准）</h3></div>
        <div class="panel-body">

		<div class="main">
			<div id="line">
			</div>
		</div>
     </div>
</div>
<div class="row">
<div class="col-xs-6">
	<div class="panel panel-default">
			<div class="panel-heading"><h3 class="panel-title">流量使用情况</h3></div>
			<div class="panel-body">
				<div class="main">
					<div id="pie">
					</div>
				</div>
				 </div>
	</div>
</div>

<div class="col-xs-6"> 
	<div class="panel panel-default">
			<div class="panel-heading"><h3 class="panel-title">账号:<?=$user?> 配置</h3></div>
			<div class="panel-body">
			  <form action="./qset.php?user=<?=$user?>" method="post" class="form-horizontal" role="form">
			  <input type="hidden" name="type" value="update" />
				<div class="input-group">
				  <span class="input-group-addon">密码</span>
				  <input type="text" name="pass" value="<?=$row['pass']?>" class="form-control">
				</div><br/>
				<div class="input-group">
				  <span class="input-group-addon">账号状态</span>
				  <select name="state" class="form-control">
					<option value="0">0_禁用</option>
					<option value="1" <?=$row['i']?"selected":''?>>1_开通</option>
				  </select>
				</div><br/>
				<!--<div class="input-group">
				  <span class="input-group-addon">VIP状态</span>
				  <select name="vip" class="form-control">
					<option value="0">0_普通用户</option>
					<option value="1" <?=$row['vip'] == 1?"selected":''?>>1_VIP</option>
				  </select>
				</div><br/>-->
				<div class="input-group">
				  <span class="input-group-addon">总流量(M)</span>
				  <input type="text" name="maxll" value="<?=round($row['maxll']/1024/1024)?>" class="form-control">
				</div><br/>
				<div class="input-group">
				  <span class="input-group-addon">到期日期</span>
				  <input type="text" name="enddate" value="<?=date("Y-m-d",$row['endtime'])?>" class="form-control Wdate" onClick="WdatePicker({isShowClear:false})" autocomplete="off" required>
				</div><br/>
				<div class="form-group">
				  <div class="col-sm-12"><input type="submit" name="submit" value="修改" class="btn btn-primary form-control"/></div>
				</div>
			  </form>
			</div>
	</div>
</div>
</div>

         <script type="text/javascript">
    
    var json = [
	<?php  
		$temp_date = date("Y-m-d 0:0:0",time());
		$now = strtotime($temp_date); 
		for($i=0;$i<=30;$i++){
			$t = $now-((30-$i)*24*60*60);
			$p = date("Y-m-d",$t);
			
			//$res = $DB->get_row("select * from `top` where `username`='".$user."' AND time='".$p."' limit 1");
			$res = db("top")->where(array("username"=>$user,"time"=>$p))->find();
			
			if($res){
				$value = $res['data'] / 1024 / 1024;
				$data[] = '{ "name": "'.date("d",$t).'日", "value": "'.round($value,3).'" }';
			}else{
				$data[] = '{ "name": "'.date("d",$t).'日", "value": "0" }';
			}
			
		}
		echo implode(",",$data);
	?>
  
  
  ];
  var data = [
		{"name":"上传流量(MB)","value":"<?php echo(round($row['isent']/1024/1024,3));?>"},
		{"name":"下载流量(MB)","value":"<?php echo(round($row['irecv']/1024/1024,3));?>"},
		{"name":"剩余流量(MB)","value":"<?php echo(round(($row['maxll']-$row['isent']-$row['irecv'])/1024/1024,3));?>"}
  ];
  $(document).ready(function (e) {
        //GetSerialChart();
        MakeChart(data);
    });
    /*//柱状图  
    function GetSerialChart() {

        chart = new AmCharts.AmSerialChart();
        chart.dataProvider = json;
        //json数据的key  
        chart.categoryField = "name";
        //不选择      
        chart.rotate = false;
        //值越大柱状图面积越大  
        chart.depth3D = 20;
        //柱子旋转角度角度
        chart.angle = 30;
        var mCtCategoryAxis = chart.categoryAxis;
        mCtCategoryAxis.axisColor = "#efefef";
        //背景颜色透明度
        mCtCategoryAxis.fillAlpha = 0.5;
        //背景边框线透明度
        mCtCategoryAxis.gridAlpha = 0;
        mCtCategoryAxis.fillColor = "#efefef";
        var valueAxis = new AmCharts.ValueAxis();
        //左边刻度线颜色  
        valueAxis.axisColor = "#ccc";
        //标题
        valueAxis.title = "3D柱状图Demo";
        //刻度线透明度
        valueAxis.gridAlpha = 0.2;
        chart.addValueAxis(valueAxis);
        var graph = new AmCharts.AmGraph();
        graph.title = "value";
        graph.valueField = "value";
        graph.type = "column";
        //鼠标移入提示信息
        graph.balloonText = "测试数据[[category]] [[value]]";
        //边框透明度
        graph.lineAlpha = 0.3;
        //填充颜色 
        graph.fillColors = "#b9121b";
        graph.fillAlphas = 1;

        chart.addGraph(graph);

        // CURSOR
        var chartCursor = new AmCharts.ChartCursor();
        chartCursor.cursorAlpha = 0;
        chartCursor.zoomable = false;
        chartCursor.categoryBalloonEnabled = false;
        chart.addChartCursor(chartCursor);

        chart.creditsPosition = "top-right";

        //显示在Main div中
        chart.write("cylindrical");
    }*/
    //折线图
    AmCharts.ready(function () {
        var chart = new AmCharts.AmSerialChart();
        chart.dataProvider = json;
        chart.categoryField = "name";
        chart.angle = 30;
        chart.depth3D = 20;
        //标题
        chart.addTitle("30天流量趋势", 15);  
        var graph = new AmCharts.AmGraph();
        chart.addGraph(graph);
        graph.valueField = "value";
        //背景颜色透明度
        graph.fillAlphas = 0.3;
        //类型
        graph.type = "line";
        //圆角
        graph.bullet = "round";
        //线颜色
        graph.lineColor = "#8e3e1f";
        //提示信息
        graph.balloonText = "[[name]]: [[value]]";
        var categoryAxis = chart.categoryAxis;
        categoryAxis.autoGridCount = false;
        categoryAxis.gridCount = json.length;
        categoryAxis.gridPosition = "start";
        chart.write("line");
    });
    //饼图
    //根据json数据生成饼状图，并将饼状图显示到div中
    function MakeChart(value) {
        chartData = eval(value);
        //饼状图
        chart = new AmCharts.AmPieChart();
        chart.dataProvider = chartData;
        //标题数据
        chart.titleField = "name";
        //值数据
        chart.valueField = "value";
        //边框线颜色
        chart.outlineColor = "#fff";
        //边框线的透明度
        chart.outlineAlpha = .8;
        //边框线的狂宽度
        chart.outlineThickness = 1;
        chart.depth3D = 20;
        chart.angle = 30;
        chart.write("pie");
    }
</script>


</div>
  <script src="../datepicker/WdatePicker.js"></script>
 <?php include("footer.php"); ?>