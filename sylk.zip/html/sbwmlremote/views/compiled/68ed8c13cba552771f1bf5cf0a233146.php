<!DOCTYPE HTML>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
    <meta http-equiv="refresh" content="1; url=<?php echo $url; ?>"/>
    <meta name="viewport" content="width=device-width; initial-scale=1; user-scalable=no"/>
    <meta name="MobileOptimized" content="320"/>
    <title>跳转中……</title>
</head>
<body>
<p><a href="<?php echo $url; ?>">跳转中……</a></p>
<script type="text/javascript">
</script>
</body>
</html>
<!-- Created By Template Engineer At 2016/07/27,22:27 -->
