<?php

/**
 *
 * @author 李玉江<liyujiang_tk@yeah.net>
 * @copyright Li YuJiang, All Rights Reserved
 * @version 2015/7/25
 * Created by IntelliJ IDEA
 */
final class GetTokenController extends ApiController
{

    public function main()
    {   $app_id = isset($_REQUEST['app_id']) ? urldecode($_REQUEST['app_id']) : "";
        $app_secret = isset($_REQUEST['app_secret']) ? urldecode($_REQUEST['app_secret']) : "";
        if (empty($app_id)) {
            $this->responseJson(0, "app id不能为空");
        }
        if (empty($app_secret)) {
            $this->responseJson(0, "AppSecret不能为空");
        }
        $userModel = new UserModel();
        $user = $userModel->findByAccount($app_id);
        if (!$user) {
            $this->responseJson(0, "AppID不存在", $app_id);
        }
        if ($userModel->buildPassword($app_secret) != $user["password"]) {
            $this->responseJson(0, "AppSecret错误", $app_secret);
        }
        if ($user["is_forbidden"] != 0){
            $this->responseJson(0, "APP禁止访问API", $_POST);
        }
        $tokenModel = new TokenModel();
        $token = $tokenModel->build($user["id"]);
        if ($tokenModel->save($user["id"], $token)) {
            $this->responseJson(1, "APP授权成功", $token);
        } else {
            $this->responseJson(0, "APP授权失败", $_POST);
        }
    }

}