<?php
return array (
  'base_url' => 'http://ip:port/sbwmlremote',
  'db.type' => 'mysql',
  'db.host' => 'localhost',
  'db.port' => 3306,
  'db.user' => 'root',
  'db.pass' => 'abc',
  'db.name' => 'ov',
)
?>
