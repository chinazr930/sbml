<?php
$mod='blank';
include("../api.inc.php");
$title='账号列表';
include './head.php';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
include './nav.php';

?>


<section id="content">
<section class="vbox">
<section class="scrollable padder">
<ul class="breadcrumb no-border no-radius b-b b-light pull-in">
	<li><a href="#"><i class="fa fa-home"></i> <?php echo $title ?></a></li>
</ul>
<section class="panel panel-default">
              <header class="panel-heading font-bold"> 账号管理 </header>
              <div class="panel-body">
				
                  <div class="line line-dashed line-lg pull-in"></div>
                  <div class="form-group">
                   


    
<?php

$my=isset($_GET['my'])?$_GET['my']:null;

if($my=='del'){
echo '<div class="panel panel-primary">
<div class="panel-heading w h"><h3 class="panel-title">删除账号</h3></div>
<div class="panel-body box">';
$user=$_GET['user'];
$sql=$DB->query("DELETE FROM `openvpn` WHERE iuser='$user'");
if($sql){echo '删除成功！';}
else{echo '删除失败！';}
echo '<hr/><a href="./gao.php">>>返回账号列表</a></div></div>';
}



elseif($my=='cc'){
echo '
<div class="panel-heading w h"><h3 class="panel-title">删除流量超出用户</h3></div>

<div class="panel-body box">
您确认要删除删除流量超出用户吗？删除后后无法恢复！<br><a href="./gao.php?my=cc2">确认</a> | <a href="javascript:history.back();">返回</a></div></div>';
}
elseif($my=='cc2'){
echo '
<div class="panel-heading w h"><h3 class="panel-title">删除流量超出用户</h3></div>
<div class="panel-body box">';
if($DB->query("DELETE FROM openvpn WHERE maxll-isent-irecv < 0")==true){
echo '<div class="box">删除成功.</div>';
}else{
echo'<div class="box">删除失败.</div>';
}
echo '<hr/><a href="./gao.php">>>返回用户列表</a></div></div>';
}

elseif($my=='dq'){
echo '
<div class="panel-heading w h"><h3 class="panel-title">删除已到期用户</h3></div>

<div class="panel-body box">
您确认要删除删除已到期用户吗？删除后后无法恢复！<br><a href="./gao.php?my=dq2">确认</a> | <a href="javascript:history.back();">返回</a></div></div>';
}
elseif($my=='dq2'){
echo '
<div class="panel-heading w h"><h3 class="panel-title">删除已到期用户</h3></div>
<div class="panel-body box">';
if($DB->query("DELETE FROM openvpn WHERE endtime < (SELECT unix_timestamp(now()))")==true){
echo '<div class="box">删除成功.</div>';
}else{
echo'<div class="box">删除失败.</div>';
}
echo '<hr/><a href="./gao.php">>>返回用户列表</a></div></div>';
}

elseif($my=='jy'){
echo '
<div class="panel-heading w h"><h3 class="panel-title">删除已禁用用户</h3></div>

<div class="panel-body box">
您确认要删除删除已禁用用户吗？删除后后无法恢复！<br><a href="./gao.php?my=jy2">确认</a> | <a href="javascript:history.back();">返回</a></div></div>';
}
elseif($my=='jy2'){
echo '
<div class="panel-heading w h"><h3 class="panel-title">删除已禁用用户</h3></div>
<div class="panel-body box">';
if($DB->query("DELETE FROM openvpn WHERE  i=0")==true){
echo '<div class="box">删除成功.</div>';
}else{
echo'<div class="box">删除失败.</div>';
}
echo '<hr/><a href="./gao.php">>>返回用户列表</a></div></div>';
}





else
	

{
if(!empty($_GET['kw'])) {
	$sql=" `iuser`='{$_GET['kw']}'";
	$numrows=$DB->count("SELECT count(*) from `openvpn` WHERE{$sql}");
	$con='包含 '.$_GET['kw'].' 的共有 <b>'.$numrows.'</b> 个账号';
}else{
	$numrows=$DB->count("SELECT count(*) from `openvpn` WHERE 1");
	$sql=" 1";
	$con='平台共有 <b>'.$numrows.'</b> 个账号';
}
echo '<form action="gao.php" method="get" class="form-inline">
  <div class="form-group">
   
    <input type="text" class="form-control" name="kw" placeholder="账号">
  </div>
  <button type="submit" class="btn btn-primary">搜索</button></br></br>
    <a href="addqq.php" class="btn btn-info">平台共有 <b>'.$numrows.'</b> 个账号</a>
  <a href="addqq.php" class="btn btn-success">添加账号</a>
  <a href="online.php" class="btn btn-success">在线用户</a>
  <a href="daochu.php" class="btn btn-success"">导出所有用户</a></br></br>
  <!--<a  class="btn btn-success" onclick="del();">删除选中</a>-->
    <a href="gao.php?my=cc" class="btn btn-danger">删除流量超出用户</a>
	  <a href="gao.php?my=dq" class="btn btn-danger">删除已到期用户</a>
	  <a href="gao.php?my=jy" class="btn btn-danger">删除已禁用用户</a>
   <a href="addqq.php" class="btn btn-info">平台共有 <b>'.$numrows.'</b> 个账号</a>
</form>';




echo $con;
?>
      <div class="table-responsive">
        <table class="table table-striped">
          <thead><tr><th><input type="checkbox" id="widuu" onclick="checkAll(this)"></th><th>服务器ID</th><th>账号</th><th>密码</th><th>添加时间</th><th>到期时间</th><th>剩余流量</th><th>总流量</th><th>状态</th><th>备注</th><th>操作</th></tr></thead>
          <tbody>
<?php
$pagesize=30;
$pages=intval($numrows/$pagesize);
if ($numrows%$pagesize)
{
 $pages++;
 }
if (isset($_GET['page'])){
$page=intval($_GET['page']);
}
else{
$page=1;
}
$offset=$pagesize*($page - 1);
//$zt = array('0'=>'<font color=green>正常</font>','1'=>'<font color=red>密码错误</font>','2'=>'<font color=red>冻结</font>','3'=>'<font color=red>开启设备锁</font>');
$rs=$DB->query("SELECT * FROM `openvpn` WHERE{$sql} order by id desc limit $offset,$pagesize");
while($res = $DB->fetch($rs))
{ ?>
<tr>
<td><input type="checkbox" name="ids" value="<?=$res['id']?>" id="box"></td>

<td><?=$res['fwqid']?></td>
<td><?=$res['iuser']?></td>
<td><?=$res['pass']?></td>
<td><?=date("Y-m-d H:i:s",$res['starttime'])?></td>
<td><?=date("Y-m-d H:i:s",$res['endtime'])?></td>
<td><?=round(($res['maxll']-$res['isent']-$res['irecv'])/1024/1024)?>MB</td>
<td><?=round(($res['maxll'])/1024/1024)?>MB</td>
<td><?=$res['i']?></td>
<td><?=$res['notes']?></td>
<td><a class="btn btn-xs btn-success" href="./qset.php?user=<?=$res['iuser']?>">配置</a>&nbsp;<a href="./gao.php?my=del&user=<?=$res['iuser']?>" class="btn btn-xs btn-danger" onclick="if(!confirm('你确实要删除此记录吗？')){return false;}">删除</a></td>
</tr>

<?php }
?>
          </tbody>
        </table>
      </div>
<?php
echo'<ul class="pagination">';
$first=1;
$prev=$page-1;
$next=$page+1;
$last=$pages;
if ($page>1)
{
echo '<li><a href="gao.php?page='.$first.$link.'">首页</a></li>';
echo '<li><a href="gao.php?page='.$prev.$link.'">&laquo;</a></li>';
} else {
echo '<li class="disabled"><a>首页</a></li>';
echo '<li class="disabled"><a>&laquo;</a></li>';
}
for ($i=1;$i<$page;$i++)
echo '<li><a href="gao.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '<li class="disabled"><a>'.$page.'</a></li>';
for ($i=$page+1;$i<=$pages;$i++)
echo '<li><a href="gao.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '';
if ($page<$pages)
{
echo '<li><a href="gao.php?page='.$next.$link.'">&raquo;</a></li>';
echo '<li><a href="gao.php?page='.$last.$link.'">尾页</a></li>';
} else {
echo '<li class="disabled"><a>&raquo;</a></li>';
echo '<li class="disabled"><a>尾页</a></li>';
}
echo'</ul>';
#分页
}
?>
    </div>
  </div>
<script type="text/javascript">
    function del(){
      var str="";
      $("input[name='ids']").each(function(){ 
          if($(this).prop('checked')){
            str += $(this).val()+","
          }
      })
      $.post('delall.php?action=delall',{ids:str},function(data){
        alert(data);
        window.location.reload();
      });
      
    }
   function checkAll(obj){
      $("input[type='checkbox']").prop('checked', $(obj).prop('checked'));
  }

</script>

 
                  
              </div>
            </section>
</section>
</section>

<a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a></section>
<aside class="bg-light lter b-l aside-md hide" id="notes">
<div class="wrapper">
	Notification
</div>
</aside>
<!-- end -->
<?php
require_once ("foot.php");
?><?php 