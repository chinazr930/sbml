<?php
$mod='blank';
include("../api.inc.php");
$title='修改密码';

if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
include './nav.php';
require_once ("head.php");

?>
<section id="content">
<section class="vbox">
<section class="scrollable padder">
<ul class="breadcrumb no-border no-radius b-b b-light pull-in">
	<li><a href="#"><i class="fa fa-home"></i> <?php echo $title ?></a></li>
</ul>
<section class="panel panel-default">
              <header class="panel-heading font-bold"> 修改管理员账号和密码 </header>
    <div class="panel-body">
		<form id="myform" class="form-horizontal" action="passwd.php" method="post">
   			<div class="form-group">
      			<label for="firstname" class="col-sm-1 control-label">新账号</label>
	      		<div class="col-sm-5">
	         		<input type="text" class="form-control" name="newname" placeholder="请输入新账号">
	      		</div>
   			</div>
		   <div class="form-group">
		      <label for="lastname" class="col-sm-1 control-label">新密码</label>
		      <div class="col-sm-5">
		         <input type="password" class="form-control" name="newpasswd" placeholder="请输入新密码">
		      </div>
		   </div>
		   <div class="form-group">
		      <div class="col-sm-offset-1 col-sm-10">
		         <button type="submit" class="btn btn-default">修改</button>
		      </div>
		   </div>
	</form>  


    </div>
</section>
</section>
</section>
</section>
<!-- end -->
<?php
require_once ("foot.php");

if(isset($_POST['newname'])&&isset($_POST['newpasswd'])) {
	// 	echo "<script language='javascript'>alert('".$_POST['newname'].$_POST['newpasswd']."')</script>";
	$newname = trim($_POST['newname']);
	$newpasswd = trim($_POST['newpasswd']);
	if($newname==""||$newpasswd=="") {
		echo "<script language='javascript'>alert('用户名和密码不能为空！')</script>";
	}else {
		$sql = "update `admin` set `username` = '".$newname."', `password` = '".$newpasswd."'";
		$result = $DB->query($sql);
		if($result) {
			echo "<script language='javascript'>alert('修改成功，请重新登录...')</script>";
			echo "<script language='javascript'>window.location.href='./index.php'</script>";
		}else {
			echo "<script language='javascript'>alert('修改失败')</script>";
		}
	}
}

?>

