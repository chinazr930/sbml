<?php
/**
 * 注册
**/
$mod='blank';
include("../api.inc.php");
$dlconfig=$DB->get_row("SELECT * FROM auth_config WHERE 1");
if($_POST['user'] && $_POST['pass']){
	$user=daddslashes($_POST['user']);
	$pass=daddslashes($_POST['pass']);
	$fwq=daddslashes($_POST['fwq']);
	$verifycode=daddslashes($_POST['verifycode']);
	$row = $DB->get_row("SELECT * FROM `openvpn` WHERE `iuser`='$user' limit 1");
	if(!is_username($user)){
		exit("<script language='javascript'>alert('用户名只能是2~20位的字母数字！');history.go(-1);</script>");
	}elseif($row){
		exit("<script language='javascript'>alert('用户名已被使用！');history.go(-1);</script>");
	}elseif(!$verifycode || $verifycode!=$_SESSION['verifycode']){
			exit("<script language='javascript'>alert('验证码不正确！');history.go(-1);</script>");
	}else{
		$DB->query("insert `openvpn`(`iuser`,`pass`,`isent`,`irecv`,`maxll`,`i`,`starttime`,`endtime`,`fwqid`) values('{$user}','{$pass}',0,0,0,0,'".time()."','".time()."','".$fwq."')");
		$row = $DB->get_row("SELECT * FROM `openvpn` WHERE `iuser`='$user' limit 1");
		if($row['id']){
			unset($_SESSION['verifycode']);
			exit("<script language='javascript'>alert('注册成功，返回登录！');window.location.href='/';</script>");
		}else{
			exit("<script language='javascript'>alert('注册失败，请联系管理员！');history.go(-1);</script>");
		}
	}
}

$fwqlist=$DB->query("SELECT * FROM auth_fwq");

$title='用户注册';
include './head.php';
?>
<!DOCTYPE html>
<html>  
<head>
    <meta charset="utf-8"/>
	<title>用户注册</title>
	<link rel="shortcut icon" href="../images/favicon.ico">
	<link href="../css/bootstrap.min.css" media="all" rel="stylesheet" type="text/css" /><link href="../css/font-awesome.css" media="all" rel="stylesheet" type="text/css" /><link href="../css/se7en-font.css" media="all" rel="stylesheet" type="text/css" /><link href="../css/style.css" media="all" rel="stylesheet" type="text/css" />
	<script src="../js/jquery.min.js" type="text/javascript"></script>
	<script src="../js/jquery-ui.js" type="text/javascript"></script>
	<script src="../js/bootstrap.min.js" type="text/javascript"></script>
	<script src="../js/raphael.min.js" type="text/javascript"></script>
	<script src="../js/jquery.mousewheel.js" type="text/javascript"></script>
	<script src="../js/jquery.vmap.min.js" type="text/javascript"></script>
	<script src="../js/jquery.vmap.sampledata.js" type="text/javascript"></script>
	<script src="../js/jquery.vmap.world.js" type="text/javascript"></script>
	<script src="../js/jquery.bootstrap.wizard.js" type="text/javascript"></script>
	<script src="../js/fullcalendar.min.js" type="text/javascript"></script>
	<script src="../js/gcal.js" type="text/javascript"></script>
	<script src="../js/jquery.dataTables.min.js" type="text/javascript"></script>
	<script src="../js/datatable-editable.js" type="text/javascript"></script>
	<script src="../js/jquery.easy-pie-chart.js" type="text/javascript"></script>
	<script src="../js/excanvas.min.js" type="text/javascript"></script>
	<script src="../js/jquery.isotope.min.js" type="text/javascript"></script>
	<script src="../js/masonry.min.js" type="text/javascript"></script>
	<script src="../js/modernizr.custom.js" type="text/javascript"></script>
	<script src="../js/jquery.fancybox.pack.js" type="text/javascript"></script>
	<script src="../js/select2.js" type="text/javascript"></script>
	<script src="../js/styleswitcher.js" type="text/javascript"></script>
	<script src="../js/wysiwyg.js" type="text/javascript"></script>
	<script src="../js/jquery.inputmask.min.js" type="text/javascript"></script>
	<script src="../js/jquery.validate.js" type="text/javascript"></script>
	<script src="../js/bootstrap-fileupload.js" type="text/javascript"></script>
	<script src="../js/bootstrap-datepicker.js" type="text/javascript"></script>
	<script src="../js/bootstrap-timepicker.js" type="text/javascript"></script>
	<script src="../js/bootstrap-colorpicker.js" type="text/javascript"></script>
	<script src="../js/bootstrap-switch.min.js" type="text/javascript"></script>
	<script src="../js/daterange-picker.js" type="text/javascript"></script>
	<script src="../js/date.js" type="text/javascript"></script>
	<script src="../js/morris.min.js" type="text/javascript"></script>
	<script src="../js/skycons.js" type="text/javascript"></script><script src="../js/jquery.sparkline.min.js" type="text/javascript"></script><script src="../js/fitvids.js" type="text/javascript"></script><script src="../js/main.js" type="text/javascript"></script><script src="../js/respond.js" type="text/javascript"></script>
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport">
  </head>
  <body class="login1">
    <!-- Login Screen -->
    <div class="login-wrapper">
      <div class="login-container">
        <img width="100" height="30" src="../images/logo-userreg%402x.png" />
        <form action="./reg.php" method="post" class="form-horizontal" role="form">
		  <div class="form-group">
            <input class="form-control" placeholder="用户名" type="text" name="user" required="required">
          </div>
          <div class="form-group">
            <input class="form-control" placeholder="密码" type="password" name="pass" required="required"> <!--<input type="submit" value="&#xf054;">-->
          </div>
		  <div class="">
			  <label class="control-label">选择服务器</label>
				<select name="fwq" class="form-control">
				<?php while($v = $DB->fetch($fwqlist)): ?>
				  <option value="<?php echo $v['id']; ?>"><?php echo $v['name']; ?></option>
				<?php endwhile; ?>
				</select>
            </div>
			<div class="input-group">
              <input type="text" name="verifycode" class="form-control" placeholder="验证码" required="required" style="max-width: 65%;display:inline-block;vertical-align:middle;"/>&nbsp;<img title="点击刷新" src="verifycode.php" onclick="this.src='verifycode.php?'+Math.random();" style="max-height:32px;vertical-align:middle;" class="img-rounded">
            </div><br/>
            <div class="form-group">
        </form>
        <div class="social-login clearfix">
		<!--  <input type="submit">  -->
		<button type="submit" class="btn btn-success icon-user pull-left"></i>  立即注册</button>
		<!--<a class="btn btn-success pull-left" input type="submit" ><i class="icon-user"></i>点击注册</a>-->
		<a class="btn btn-primary icon-cloud pull-right twitter" href="../">  用户登录</a>
        </div>
    <!-- End Login Screen -->
  </body>

</html>

<?php footer(); ?>