<?php
//decode by QQ:270656184 http://www.yunlu99.com/
header("location: ./user/login.php");